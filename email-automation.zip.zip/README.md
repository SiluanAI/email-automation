# Email Automation System

Sistem automat de trimitere emailuri pentru dispeceri de transport.

## Features
- Upload CSV cu lista de emailuri
- Template-uri bilingve (română/engleză)
- Progress tracking în timp real
- Integrare Gmail

## Usage
1. Încarcă fișierul CSV (format: email,nume)
2. Verifică preview-ul emailurilor
3. Trimite emailurile
4. Urmărește progresul în timp real

## Deploy
Sistemul este configurat pentru deploy pe Render.